package android.virlie.uas_pbb_virlie

import android.virlie.uas_pbb_virlie.databinding.CardItemBinding
import androidx.recyclerview.widget.RecyclerView

class CardViewHolder (
    private val cardItemBinding: CardItemBinding,
    private val clickListener: ProdukClickListener
) : RecyclerView.ViewHolder(cardItemBinding.root)
{
    fun bindProduk(produk:Produk){
        cardItemBinding.cover.setImageResource(produk.cover)
        cardItemBinding.title.text = produk.title

        cardItemBinding.cardView.setOnClickListener {
            clickListener.onClick(produk)
        }
    }
}