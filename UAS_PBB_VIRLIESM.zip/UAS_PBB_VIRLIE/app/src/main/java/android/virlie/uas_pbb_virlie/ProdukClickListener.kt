package android.virlie.uas_pbb_virlie

interface ProdukClickListener {
    fun onClick(produk: Produk)
}